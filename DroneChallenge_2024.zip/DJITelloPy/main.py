from Tello_Control import TelloC


def main():
    control = TelloC()   
    print("Started")

if __name__ == "__main__":
    main()